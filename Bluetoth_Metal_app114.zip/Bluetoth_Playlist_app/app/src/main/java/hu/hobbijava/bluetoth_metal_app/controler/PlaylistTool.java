package hu.hobbijava.bluetoth_metal_app.controler;

import android.os.Environment;

import java.io.File;
import java.io.FileFilter;
import java.util.LinkedHashMap;
import java.util.Map;

public class PlaylistTool {
    private PlaylistTool(){}

    private static Map<String,File> playlistMap;
    public static final String MUSIC_Directory=Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC).getAbsolutePath();
    public static final String APP_Directory= Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC)+
            "/BlueToothMusic_Playlist_Files";
    static {
        playlistMap = new LinkedHashMap<>();




    }

    public static boolean createAppDir()  {
        File musicDir= new File(MUSIC_Directory);
        if (!musicDir.exists()){
            musicDir.mkdir();
        }

        File appDir = new File(APP_Directory);
        if (!appDir.exists() ){
            return appDir.mkdir();


        }
        return appDir.canRead();
    }
    static void readAppDir()  {
        File f = new File(APP_Directory);
        if (f.exists()) {
            File[] m3uFiles = f.listFiles(new FileFilter() {
                @Override
                public boolean accept(File pathname) {
                    if (pathname.toString().endsWith("m3u")
                            || pathname.toString().endsWith("pls")) {
                        return true;
                    }
                    return false;
                }
            });
            for (File file : m3uFiles) {

                String fileName= file.getName().split("\\.")[0];


                playlistMap.put(fileName, file);

            }
        }else {
            createAppDir();
            readAppDir();
        }


    }

    /**
     * @return
     */

    public static final Map<String, File> getPlaylistMap()  {
        readAppDir();
        return playlistMap;
    }
}
