package hu.hobbijava.bluetoth_metal_app.view;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import java.io.File;

import hu.hobbijava.bluetoth_metal_app.R;
import hu.hobbijava.bluetoth_metal_app.controler.PlaylistTool;
import hu.hobbijava.bluetoth_metal_app.view.MainActivity;

public class LauncherActivity extends AppCompatActivity {


    private File appDir;
    private File musicDir;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_launcher);
        musicDir = new File(PlaylistTool.MUSIC_Directory);
        appDir = new File(PlaylistTool.APP_Directory);
        if (appDir.exists() && appDir.canRead() && appDir.canWrite()) {

            StartMainActivity();

        } else {
            if (Build.VERSION.SDK_INT >= 23) {
                permissionQuestion();

            } else {
                createAppDir();

            }
        }


    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private void permissionQuestion() {

        requestPermissions(new String[]{ Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 555);


    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        if (requestCode == 555) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED &&
                    grantResults[1] == PackageManager.PERMISSION_GRANTED) {


                createAppDir();


            } else {
                showToast(getString(R.string.required_permission_message));
                permissionQuestion();
            }
        }
    }

    private void createAppDir() {

        Button okButton = findViewById(R.id.start_button);
        okButton.setVisibility(View.VISIBLE);
        TextView initTextView = findViewById(R.id.init_textView);
        initTextView.setVisibility(View.VISIBLE);
        if (PlaylistTool.createAppDir()) {
            initTextView.setText("Created " + musicDir.getName() + "/"
                    + appDir.getName() + " .Click on the start button");

            okButton.setOnClickListener(l -> {
                StartMainActivity();

            });
        } else {
            initTextView.setText(R.string.fail_init_message);
            okButton.setEnabled(false);
        }


    }

    private void StartMainActivity() {
        Intent i = new Intent(this, MainActivity.class);
        startActivity(i);
    }

    private void showToast(String message) {

        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }
}
