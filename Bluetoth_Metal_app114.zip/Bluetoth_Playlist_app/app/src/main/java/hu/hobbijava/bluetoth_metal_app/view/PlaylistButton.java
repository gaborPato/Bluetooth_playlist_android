package hu.hobbijava.bluetoth_metal_app.view;

import android.content.Context;

import java.io.File;

public class PlaylistButton extends androidx.appcompat.widget.AppCompatButton {


    private  String label;



    private File playlistFile;

     PlaylistButton(Context context, String label, File playlistFile) {
        super(context);

        this.label= label==null? "":label;
        this.playlistFile = playlistFile;

        this.setText(label);


    }

     String getLabel() {
        return label;
    }

     void setLabel(String label) {
        this.label = label != null? label:"";
        this.setText(label);
    }

     File getPlaylistFile() {
        return playlistFile;
    }

     void setPlaylistFile(File playlistFile) {
        this.playlistFile = playlistFile;
    }
}
