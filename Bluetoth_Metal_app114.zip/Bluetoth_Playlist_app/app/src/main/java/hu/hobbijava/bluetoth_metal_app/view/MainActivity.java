package hu.hobbijava.bluetoth_metal_app.view;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.bluetooth.BluetoothAdapter;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.io.File;
import java.util.Map;

import hu.hobbijava.bluetoth_metal_app.R;
import hu.hobbijava.bluetoth_metal_app.controler.PlaylistTool;
import map_tool.MapTool;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private BluetoothAdapter bt_Adapter;
    private ImageView bt_state_ImageView;
   // private  static final int BT_ENABLE_REQUEST_CODE=1212;
    private  static final int USERBUTTON_COUNT=25;
    private PlaylistButton[] playlistButtons;
    private LinearLayout arraysLinearLayout;

    private  static boolean dissabeBT_on_backPress;

    private final int ButtonArrayStart_ID = 2143;
    private  Map<String, File> playlistData;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        playlistButtons = new PlaylistButton[USERBUTTON_COUNT];
        bt_state_ImageView= findViewById(R.id.bluetooth_state_ico);
        arraysLinearLayout=findViewById(R.id.button_array_linear_layout);
        bt_Adapter=BluetoothAdapter.getDefaultAdapter();
        checkBT_adapter_and_start_BT();
        try {
            initPlaylistRadioButton();
        } catch (Exception e) {
            showToast(e.getMessage());
        }
        addButtonsToLayout();
    }



    private void checkBT_adapter_and_start_BT() {
        if (bt_Adapter== null){
            showToast("Bluetooth is not available");
          return;
        }
        if (bt_Adapter.isEnabled()){
            showToast("Bluetooth is already turned on");
            bt_state_ImageView.setImageResource(R.drawable.ic_bt_on);
        }
    }
    private void initPlaylistRadioButton() throws Exception {
        int height = (int) (getResources().getDisplayMetrics().density * 50);

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams
                (ViewGroup.LayoutParams.MATCH_PARENT, height);
        params.setMargins(20, 6, 20, 6);
        for (int i = 0; i< playlistButtons.length; i++){
            playlistButtons[i]=new PlaylistButton(MainActivity.this,null,null);
            playlistButtons[i].setOnClickListener(this);
            playlistButtons[i].setLayoutParams(params);
            playlistButtons[i].setId(ButtonArrayStart_ID+i);
        }

        refreshPlaylistButtonsDatas();

    }

    private void refreshPlaylistButtonsDatas() {
        playlistData= PlaylistTool.getPlaylistMap();
        for (int i = 0; i < playlistData.size(); i++) {
            playlistButtons[i].setLabel((String) MapTool.getEntryKey(playlistData,i));
            playlistButtons[i].setPlaylistFile((File) MapTool.getEntryValue(playlistData,i));

        }
    }

    private void addButtonsToLayout() {
        for (Button element : playlistButtons) {
            arraysLinearLayout.addView(element);
        }

    }


    private void showToast(String message){
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }



    @Override
    public void onBackPressed() {

        if (bt_Adapter!= null && bt_Adapter.isEnabled()){

            AlertDialog.Builder builder = showCloseAlertDialog();
            builder.setOnDismissListener(new DialogInterface.OnDismissListener() {
                @Override
                public void onDismiss(DialogInterface dialog) {
                    if (dissabeBT_on_backPress){
                        bt_Adapter.disable();

                        closeApp();
                    }else {
                        closeApp();
                    }
                }


            });
            builder.create().show();


        }else {
            closeApp();
        }

    }
    private void closeApp(){



        Intent i = new Intent(Intent.ACTION_MAIN);
        i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        i.addCategory(Intent.CATEGORY_HOME);
        startActivity(i);

    }


    @Override
    protected void onRestart() {
        pln("onRestart");
        refreshPlaylistButtonsDatas();
        super.onRestart();
    }

  public static void pln(Object object){
        System.out.println(object.toString());
    }

    private AlertDialog.Builder showCloseAlertDialog() {
       // final AtomicBoolean dissBt = new AtomicBoolean(false);
        AlertDialog.Builder builder= new AlertDialog.Builder(this);
        builder.setTitle("BLUETOOTH?");
        builder.setMessage(R.string.close_alert_message);
        builder.setCancelable(false);
        builder.setPositiveButton("yes", new DialogInterface.OnClickListener() {


            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (which == -1){
                   dissabeBT_on_backPress=true;
                    dialog.dismiss();
                }
            }
        });
        builder.setNegativeButton("no", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (which != -1){
                    dissabeBT_on_backPress=false;
                    dialog.cancel();
                }
            }
        });


       return builder;
    }


    @Override
    public void onClick(View v) {

        for (int i = 0; i< playlistButtons.length; i++){
            if (v.getId() == ButtonArrayStart_ID+i){
                pln(v.getId());
                if (playlistButtons[i].getLabel().equals("")){
                    return;
                }

                openPlayListFile(playlistButtons[i].getPlaylistFile());
            }
        }
        if (v.getId()== bt_state_ImageView.getId()){
           if (bt_Adapter== null) return;
            if (bt_Adapter.isEnabled()){

                try {
                    bt_Adapter.disable();
                    bt_state_ImageView.setImageResource(R.drawable.ic_bt_off);
                }catch (Exception bte){
                    Log.e("bterror",bte.getMessage());
                }

            }else {
                try{
                    bt_Adapter.enable();
                    bt_state_ImageView.setImageResource(R.drawable.ic_bt_on);
                }catch (Exception bte){
                    Log.e("bterror",bte.getMessage());
                }

            }
        }
    }



    private void openPlayListFile(File file) {
        Intent i = new Intent(Intent.ACTION_VIEW);
        Uri uri= Uri.parse(file.getAbsolutePath());
        i.setDataAndType(uri,"audio/x-mpegurl");
       try {
           startActivity(i);
       }catch (Exception e){
           showToast(getString(R.string.recommended_player));

        }

    }


}
